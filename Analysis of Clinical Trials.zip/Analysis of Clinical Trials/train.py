import joblib
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Load the datasets
df1 = pd.read_csv("initial_phase_dataset.csv")
df2 = pd.read_csv("second_phase_dataset.csv")

# Combine the datasets
df = pd.concat([df1, df2], ignore_index=True)

# Drop non-numeric and irrelevant columns
df = df.drop(['Name', 'Patient ID', 'Observations'], axis=1)

# Encode categorical variables
df = pd.get_dummies(df, columns=['Gender', 'Disorder', 'Dosage Stage', 'Initial Response', 'Side Effects', 'Lab Result'])

# Split the combined data into initial phase and second phase
df_initial_phase = df[df['Dosage Stage_Stage 2'] == 1]
df_second_phase = df[df['Dosage Stage_Stage 3'] == 1]

# Function to train and save model
def train_and_save_model(df, model_name, scaler_name, feature_names_name):
    X = df.drop('Outcome', axis=1)
    y = df['Outcome']

    # Encode the target variable if it's categorical
    y = pd.get_dummies(y).values.argmax(1) if y.dtype == 'O' else y

    # Preprocess the data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Save the feature names
    feature_names = X.columns
    joblib.dump(feature_names, feature_names_name)

    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Train the model
    rf_model = RandomForestClassifier()
    rf_model.fit(X_train, y_train)

    # Save the model and the scaler
    joblib.dump(rf_model, model_name)
    joblib.dump(scaler, scaler_name)

    print(f"{model_name}, {scaler_name}, and {feature_names_name} have been saved successfully.")

# Train and save the initial phase model
train_and_save_model(df_initial_phase, 'random_forest_model_initial_phase.pkl', 'scaler_initial_phase.pkl', 'feature_names_initial_phase.pkl')

# Train and save the second phase model
train_and_save_model(df_second_phase, 'random_forest_model_second_phase.pkl', 'scaler_second_phase.pkl', 'feature_names_second_phase.pkl')
